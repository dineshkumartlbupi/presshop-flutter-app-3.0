import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_witai/network/network.dart';
import 'package:presshop/utils/CommonSharedPrefrence.dart';
import '../../main.dart';
import '../../utils/Common.dart';
import '../../utils/networkOperations/NetworkResponse.dart';


class ChatBotScreen extends StatefulWidget {
  const ChatBotScreen({super.key});

  @override
  State<ChatBotScreen> createState() => _ChatBotScreenState();
}

class _ChatBotScreenState extends State<ChatBotScreen>
    /*implements NetworkResponse*/ {
  final messageController = TextEditingController();
  final scrollController = ScrollController();
  dynamic response;
  List<ChatModel> chatList = [];
  bool isTyping = false;
  String searchValue = "";

  @override
  void initState() {
  //  callGetMessageApi();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(
          toolbarHeight: size.width * numD20,
          automaticallyImplyLeading: false,
          elevation: 0,
          actions: [
            IconButton(
              splashRadius: size.width * 0.05,
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Stack(
                alignment: Alignment.center,
                children: [
                  Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(35)),
                    child: Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(35),
                        image: DecorationImage(
                          image: AssetImage('assets/icons/eclips.png'),
                        ),
                      ),
                      padding: EdgeInsets.all(8),
                    ),
                  ),
                  Icon(
                    Icons.clear,
                    size: 20,
                  )
                ],
              ),
            )
          ],
          title: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                width: size.width * numD13,
                height: size.width * numD13,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                ),
                child: ClipRRect(
                  borderRadius:
                  BorderRadius.all(Radius.circular(size.width * numD26)),
                  child: Image.asset(
                    "assets/icons/natureYogiLogo.png",
                    fit: BoxFit.fill,
                    width: size.width * numD13,
                    height: size.width * numD13,
                  ),
                ),
              ),
              SizedBox(
                width: size.width * numD025,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Nature Yogi Support",
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: size.width * numD04,
                        fontWeight: FontWeight.w600),
                  ),
                  SizedBox(
                    height: size.width * numD01,
                  ),
                  isTyping
                      ? Text(
                    "Typing...",
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: Colors.grey,
                        fontSize: size.width * numD035,
                        fontWeight: FontWeight.w400),
                  )
                      : Container(),
                ],
              ),
            ],
          ),
          centerTitle: false,
        ),
        body: Container(
          margin: EdgeInsets.symmetric(horizontal: size.width * numD04),
          child: Column(
            children: [
              Expanded(
                  child: ListView.builder(
                      controller: scrollController,
                      physics: const BouncingScrollPhysics(),
                      itemCount: chatList.length,
                      itemBuilder: (context, index) {
                        return chatList[index].isUser
                            ? Align(
                          alignment: Alignment.topRight,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                padding:
                                EdgeInsets.all(size.width * numD025),
                                constraints: BoxConstraints(
                                    maxWidth: size.width * numD60),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(
                                          size.width * numD025),
                                      topRight: Radius.circular(
                                          size.width * numD025),
                                      bottomLeft: Radius.circular(
                                          size.width * numD025),
                                    ),
                                    color: Colors.grey.shade400),
                                child: Text(
                                  chatList[index].message,
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: size.width * numD035,
                                      fontWeight: FontWeight.w400),
                                ),
                              ),
                              Text(
                                dateTimeFormatter(
                                  dateTime: chatList[index].time,format: "hh:mm a", ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: size.width * numD03,
                                    fontWeight: FontWeight.w400),
                              ),
                            ],
                          ),
                        )
                            : Align(
                          alignment: Alignment.topLeft,
                          child: Row(
                            children: [
                              Image.asset(
                                "assets/icons/natureYogiLogo.png",
                                fit: BoxFit.fill,
                                width: size.width * numD09,
                                height: size.width * numD09,
                              ),
                              Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    padding: EdgeInsets.all(
                                        size.width * numD025),
                                    constraints: BoxConstraints(
                                        maxWidth: size.width * numD60),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(
                                              size.width * numD025),
                                          topRight: Radius.circular(
                                              size.width * numD025),
                                          bottomRight: Radius.circular(
                                              size.width * numD025),
                                        ),
                                        color: colorThemePink),
                                    child: Text(
                                      chatList[index].message,
                                      style: TextStyle(
                                          fontSize: size.width * numD035,
                                          fontWeight: FontWeight.w400),
                                    ),
                                  ),
                                  Text(
                                    dateTimeFormatter(
                                      dateTime: chatList[index].time,format: "hh:mm a", ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        color: Colors.grey,
                                        fontSize: size.width * numD03,
                                        fontWeight: FontWeight.w400),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      })),
              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.only(
                    top: size.width * numD04, bottom: size.width * numD04),
                padding: EdgeInsets.all(size.width * numD01),
              //  decoration: commonDecoration(size),
                child: TextFormField(
                    controller: messageController,
                    style: TextStyle(
                      fontSize: size.width * numD035,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 4,
                    minLines: 1,
                    cursorHeight: 20,
                    textInputAction: TextInputAction.next,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    decoration: InputDecoration(
                      contentPadding: EdgeInsets.only(
                          left: size.width * numD035,
                          top: size.width * numD035,
                          bottom: size.width * numD01),
                      hintText: "Type your message..",
                      filled: false,
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      disabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      focusedErrorBorder: InputBorder.none,
                      errorBorder: InputBorder.none,
                      suffixIcon: Container(
                        width: size.width * numD12,
                        height: size.width * numD12,
                        padding: EdgeInsets.all(size.width * numD03),
                        child: ElevatedButton(
                            onPressed: () {
                              if (messageController.text.isNotEmpty) {
                                isTyping = true;
                                searchValue = messageController.text;
                                chatList.add(ChatModel(
                                    message: messageController.text,
                                    isUser: true,
                                    time: DateTime.now().toString()));
                             //   callAddMessageApi(messageController.text, DateTime.now().toString(), "true");
                                messageController.clear();
                                setState(() {});
                                getResponse();
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              elevation: 0,
                              shape: const CircleBorder(),
                              padding: EdgeInsets.zero,
                              backgroundColor: Colors.transparent,
                            ),
                            child: Image.asset(
                              "assets/send_icon.png",
                              color: colorThemePink,
                            )),
                      ),
                    )),
              ),
            ],
          ),
        ));
  }

/*  callAddMessageApi(String message, String time, String isUser) {
    try {
      Map<String, String> map = {
        "user_id": sharedPreferences!.getString(userIdKey).toString(),
        "message": message,
        "time": time,
        "is_user": isUser,
      };
      debugPrint("map::::$map");

      NetworkClass.fromNetworkClass(addMessageApi, this, addMessageApiReq, map)
          .callPostService(context, false);
    } on Exception catch (exception) {
      print(exception);
    }
  }

  callGetMessageApi() {
    try {
      NetworkClass(
          getMessageApi +
              "user_id=${sharedPreferences.getString(userIdKey)}",
          this,
          getMessageApiReq)
          .callGetService(context, false);
    } on Exception catch (exception) {
      print(exception);
    }
  }*/

  void getResponse() async {
    final wit = WitManager(
        utterance: searchValue, params: 'message', headers: '',/* headers: Secret.witAiHeader*/);
    response = await wit.fetchLink();
    debugPrint("Response :: $response");

    if (response != null) {

      response['traits'].forEach((key, valueList) {
        for (var item in valueList) {
          String botReply = item['value'];
          chatList.add(ChatModel(
              message: botReply,
              isUser: false,
              time: DateTime.now().toString()));
       //   callAddMessageApi(botReply, DateTime.now().toString(), "false");
        }
      });

      var intentList = response['intents'] as List;

      if(intentList.isEmpty){
        chatList.add(ChatModel(
            message: "Sorry !! \nI did not understand.",
            isUser: false,
            time: DateTime.now().toString()));
       // callAddMessageApi("Sorry! I did not understand.", DateTime.now().toString(), "false");
      }

    } else {
      debugPrint(":::: Response is Null ::::");
    }

    isTyping = false;
    scrollController.animateTo(scrollController.position.maxScrollExtent + 60,
        duration: const Duration(microseconds: 500), curve: Curves.bounceIn);
    setState(() {});
  }

/*  @override
  void onError({Key? key, required int requestCode, required String response}) {
    try {
      switch (requestCode) {
        case addMessageApiReq:
          debugPrint("addMessageApiReq error:::$response");
          break;
        case getMessageApiReq:
          debugPrint("getMessageApiReq error :::: $response");
      }
    } on Exception catch (exception) {
      print(exception);
    }
  }

  @override
  void onResponse({Key? key, required int requestCode, required String response}) {
    try {
      switch (requestCode) {
        case addMessageApiReq:
          debugPrint("addMessageApiReq success:::$response");
          break;
        case getMessageApiReq:
          debugPrint("getMessageApiReq success :::: $response");
          var data = jsonDecode(response);
          var list = data['response'] as List;

          chatList = list.map((e) => ChatModel.fromJson(e)).toList();
          debugPrint("ChatListLength : ${chatList.length}");

          setState(() {});

          Future.delayed(Duration(seconds: 1), () {
            scrollController.animateTo(
                scrollController.position.maxScrollExtent + 60,
                duration: const Duration(microseconds: 500),
                curve: Curves.bounceIn);
          });
      }
    } on Exception catch (exception) {
      print(exception);
    }
  }*/
}

class ChatModel {
  String message = "";
  String time = "";
  bool isUser = false;

  ChatModel({
    required this.message,
    required this.isUser,
    required this.time,
  });

  factory ChatModel.fromJson(Map<String, dynamic> json) {
    return ChatModel(
        message: json['message'],
        isUser: json['is_user'] == "true" ? true : false,
        time: json['time']);
  }
}
